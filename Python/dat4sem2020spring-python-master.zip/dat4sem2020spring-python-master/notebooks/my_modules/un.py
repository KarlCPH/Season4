import global_warming

status = global_warming.global_warming_status()
print('UN expert panel says: ' + status)
print(__name__)
