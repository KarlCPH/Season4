import sys
if __name__ == '__main__':
    # Call me from the CLI for example with:
    # python your_script.py arg_1 [arg_2 ...]
    for arg in sys.argv:
        print(arg)
